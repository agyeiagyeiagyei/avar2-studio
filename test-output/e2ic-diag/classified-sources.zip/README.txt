Sources for Crispy
==================

Written by avar2-studio 0.1.0 (commit 138fdc7).
Source file: Crispy.glyphs
sha256: e10428143447f49cf39053f0261a7099ce87742bde7d15beb783e8d7d05d5cee

Composed into the masters: round_corners, slant, spac_widthaware, the SPAC axis as metrics-only twin sources

No row sits at the axis defaults, so the sources rest at the compiled origin; the studio's TTF relocates a default at build time (docs/decisions/0001-build-time-default-relocation.md).

The sources rest at the compiled origin; the studio's font relocates its default to the ORIGIN row, so the default row differs there.

Build:
    fontmake -m Crispy.designspace -o variable
    # or, through the studio's own toolchain:
    gftools builder Crispy.designspace
